package couchbase;
import com.couchbase.client.core.CouchbaseException;
import com.couchbase.client.java.*;

import com.couchbase.client.java.document.JsonDocument;
import com.couchbase.client.java.document.json.JsonArray;
import com.couchbase.client.java.document.json.JsonObject;
import com.couchbase.client.java.env.CouchbaseEnvironment;
import com.couchbase.client.java.env.DefaultCouchbaseEnvironment;

import java.util.UUID;


public class QuickStartCouchbase {
    public static <MutationResult, DocumentExistsException extends Throwable> void main(String[] args) {
        try {
            //this tunes the SDK (to customize connection timeout)
            CouchbaseEnvironment env = DefaultCouchbaseEnvironment.builder()
                    .connectTimeout(50000) //10000ms = 10s, default is 5s
                    .build();
            System.out.println("Create connection");
            //use the env during cluster creation to apply
            Cluster cluster = CouchbaseCluster.create(env, "127.0.0.1:8091");

            System.out.println("Try to openBucket");
            Bucket bucket1 = cluster.openBucket("example");
            //you can also force a greater timeout here (cluster.openBucket("beer-sample", 10, TimeUnit.SECONDS))

            System.out.println("Upserting data");
            JsonDocument doc = JsonDocument.create("10", JsonObject.create().put("name", "Aishwarya"));
            JsonDocument doc1 = JsonDocument.create("20", JsonObject.create().put("Department", "Computer"));
            JsonDocument doc2 = JsonDocument.create("30", JsonObject.create().put("email", "Aishwarya@gmail.com"));
            System.out.println(bucket1.upsert(doc));
            System.out.println(bucket1.upsert(doc1));
            System.out.println(bucket1.upsert(doc2));

//            System.out.println("Inserting data");
//            JsonDocument doc = JsonDocument.create("20", JsonObject.create().put("name", "Mrunmayee"));
//            System.out.println(bucket1.insert(doc));

            System.out.println("Retriving data");
            System.out.println(bucket1.get("10"));

            System.out.println("Replacing Existing data with the given ID");
            doc = JsonDocument.create("10", JsonObject.empty().put("name", "Karthik"));
            // Changes value from Aishwarya to Karthik
            System.out.println(bucket1.replace(doc));

            System.out.println("Removing the document");
            JsonDocument removed = bucket1.remove("20");

            System.out.println("disconnect");
            cluster.disconnect();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}